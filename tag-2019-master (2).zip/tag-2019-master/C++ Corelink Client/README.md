# Introduction
This is a basic implementation of the C++ client for corelink.
Currently there is only support for windows though there shouldn't be many changes required to get it working on mac/linux (need to implement the proper socket library).

## Required files
CoreLink.cpp

CoreLink.h

SafeQueue.h

rapidjson folder

## Explanation
<img src="C++ Corelink.png" width=500><br>

Corelink.h (main) is the header file heading to the funcitons in the Corelink.cpp.
```c++
namespace CoreLink {
    class SocketInit;
    class CoreLink;
    ...    
}
```
Intialization of the two classes (SocketInit is the singleton class, not used)


```c++
CoreLink();
CoreLink(const std::string& username, const std::string& password, const std::string& ip = "127.0.0.1", const u_short& port = ((u_short)20010));
void SetUserData(const std::string& username, const std::string& password);
void Connect(const std::string& ip = "127.0.0.1", const u_short& port = ((u_short)20010));
```
Intialization of the connection to Corelink.
If the default is not used, you have to connect it manually.


```c++
int CreateSenderStream(const std::string& workspace, const int protocol, const std::string& type, const std::string& meta = "", bool echo = false);
void StreamSend(const int index, const std::string& message);
```
Intialization of the sender stream returning the index to the stream iteself.
This index is used when sending messages.


```c++
void CreateRecieverStream(const std::string& workspace, const int protocol, const std::vector<std::string>& type, bool echo, bool alert, void(*func)(const CoreLink::RecievedPacket&));
struct RecievedPacket {
    long long time;
    std::string streamID;
    std::string msg;
    };
```
Intialization of the receiver stream; user passes a user defined function that takes the parameter (const CoreLink::CoreLink::RecievedPacket&).


Corelink.cpp is the source file containing implementation of corelink client.

Test.cpp demonstrates the use of the client in a windows console application.
(It needs some cleaning up but the only thing really needed to use the client is #include "CoreLink.h").

## Further work
1. Cross platform support (non-windows sockets).
2. Clean up logic/refractor naming of variables to make improvements more easily.
3. Implement other Corelink functionality.
4. Optimize code to reduce latency, improve performance, and if possible minimize memory footprint.


## Possible Optimizations
1. Passing pointers (references to allocated memory) into queues instead of copying values into queue.
2. Compare performance of using rapid json for string creation vs string/stringstream.
3. Thread pool for recieved message processing?