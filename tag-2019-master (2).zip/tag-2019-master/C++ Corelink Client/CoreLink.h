#pragma once
#include <string>
#include <vector>
#include <map>
#include <WS2tcpip.h>

#include "SafeQueue.h"

#pragma comment (lib,"ws2_32.lib")

#define PROTOCOL_UDP 0
#define PROTOCOL_TCP 1

namespace CoreLink {
    class SocketInit;
    class CoreLink;
    /*
    Uses a singleton setup to initialize Winsock before actual use and calls destructor automatically on termination of program.
    User does not need to touch this.
    */
    class SocketInit {
    private:
        friend class CoreLink;
        //used to ensure that the corelinks are deleted before sockets close
        std::vector<CoreLink*> coreLinks;

        SocketInit();
        ~SocketInit();
        static SocketInit instance;
    };

    class CoreLink
    {
    public:
        //Stores recieved data
        struct RecievedPacket {
            long long time;
            std::string streamID;
            std::string msg;
        };

        //if default initialized, needs to set user data followed by connecting
        CoreLink();
        //if parameters are passed, connection is automatic
        CoreLink(const std::string& username, const std::string& password, const std::string& ip = "127.0.0.1", const u_short& port = ((u_short)20010));
        ~CoreLink();

        /*
        User calls theses functions to connect to Corelink with username and password. Failure to connect will terminate program. By default Corelink server should be on 128.122.215.23 and localhost is on 127.0.0.1
        */
        void SetUserData(const std::string& username, const std::string& password);
        void Connect(const std::string& ip = "127.0.0.1", const u_short& port = ((u_short)20010));

        void Disconnect();
        
        /*
        Creates a senderstream and returns a int handler for later use
        */
        int CreateSenderStream(const std::string& workspace, const int protocol, const std::string& type, const std::string& meta = "", bool echo = false);
        //requires an integer handler to the stream
        void StreamSend(const int index, const std::string& message);

        /*
        Creates a senderstream
        alert is not handled and should be implemented later
        Takes a non-thread safe function to call upon recieving message
        */
        void CreateRecieverStream(const std::string& workspace, const int protocol, const std::vector<std::string>& type, bool echo, bool alert, void(*func)(const CoreLink::RecievedPacket&));

    private:
        struct SendStreamData {
            int mtu;
            int proto;
            std::string streamID;
        };
        struct RecvStreamData {
            int mtu;
            int proto;
            void(*func)(const CoreLink::RecievedPacket&);
        };

        //used to keep track of running state and close threads
        bool running = true;
        
        bool tcp_send(const std::string & msg, int len = -1);

        std::string username;
        std::string password;

        SOCKET tcpsock;
        sockaddr_in hint;
        
        std::string token;
        std::string serverIP;
        std::string clientIP;
        int sourcePort;

        SOCKET tcpthreadsock;
        SOCKET udpthreadsock;

        //Sender variables
        SafeQueue<std::string> tcpSendQueue;
        SafeQueue<std::string> udpSendQueue;
        void tcp_send_thread();
        void udp_send_thread();
        std::thread tcpSendThread;
        std::thread udpSendThread;
        std::vector<SendStreamData> sendStreams;

        void StreamSend(const std::string& streamid, const int proto, const std::string& message);

        //Reciever variables
        std::map<std::string, CoreLink::RecvStreamData> recvStreams;
        std::map<std::string, std::vector<std::string>> recvStreamPtrs;
        //in the future, need to consider fragmented/incomplete messages
        void tcp_recv_thread();
        void udp_recv_thread();
        void proc_message(char* ptr, int len);
        void recv_thread();
        std::thread tcpRecvThread;
        std::thread udpRecvThread;
        std::thread recvThread;
        //Probably not the best idea to write it out like this but its a hacky solution that works
        SafeQueue<std::pair<CoreLink::RecievedPacket, void(*)(const CoreLink::RecievedPacket&)>> recvQueue;

    };
}