// Test.cpp : This file contains is for a console application that uses the Windows C++ sockets to connect to corelink

#include "pch.h"
#include <iostream>
#include <WS2tcpip.h>
#pragma comment (lib,"ws2_32.lib")
#include "CoreLink.h"

#include <chrono>

//allows destructors to be called when clicking the x on the console window
BOOL WINAPI ConsoleHandlerRoutine(DWORD dwCtrlType) {
    if (CTRL_CLOSE_EVENT == dwCtrlType) {
        exit(0);
        return TRUE;
    }
    return FALSE;
}
long long msgtotal = 0;
long long count = 0;
void testfunc1(const CoreLink::CoreLink::RecievedPacket& packet) {
    msgtotal += packet.msg.size();
    ++count;
}

void testfunc2(const CoreLink::CoreLink::RecievedPacket& packet) {
    std::cout << "func2:" << packet.msg << std::endl;
}

int main() {
    CoreLink::CoreLink link("Testuser", "Testpassword","128.122.215.23");
    //CoreLink::CoreLink link("Testuser", "Testpassword","127.0.0.1");
    
    //link.CreateRecieverStream("Holodeck", PROTOCOL_UDP, { "3d" }, true, true, nullptr);
    link.CreateRecieverStream("Holodeck", PROTOCOL_UDP, { "3d" }, true, true, testfunc1);
    //link.CreateRecieverStream("Holodeck", PROTOCOL_TCP, { "3d" }, true, true, testfunc2);
    //int index1 = link.CreateSenderStream("Holodeck", PROTOCOL_UDP, "3d");
    //int index2 = link.CreateSenderStream("Holodeck", PROTOCOL_UDP, "3d");
    //int index3 = link.CreateSenderStream("Holodeck", PROTOCOL_TCP, "3d");
    //int index4 = link.CreateSenderStream("Holodeck", PROTOCOL_TCP, "3d");
    SetConsoleCtrlHandler(ConsoleHandlerRoutine, TRUE);
    long long time = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    while (true){
        long long now = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        if (now > time) {
            time = now + 1000;
            std::cout << msgtotal << " " << count << std::endl;
            //link.StreamSend(index1, "1");
            //link.StreamSend(index2, "2");
            //link.StreamSend(index3, "3");
            //link.StreamSend(index4, "4");
        }
    }
}