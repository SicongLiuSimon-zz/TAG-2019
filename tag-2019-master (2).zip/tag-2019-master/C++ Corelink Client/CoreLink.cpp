#include "pch.h"
#include "CoreLink.h"

#include <iostream>
#include <sstream>
#include <chrono>

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

CoreLink::SocketInit CoreLink::SocketInit::instance;
CoreLink::SocketInit::SocketInit() {
    WSADATA data;
    int wsOk = WSAStartup(MAKEWORD(2, 0), &data);
    if (wsOk != 0) {
        std::cout << "Cannot start Windows socket" << std::endl;
        exit(0);
    }
    std::cout << "Started up Windows socket" << std::endl;
}
CoreLink::SocketInit::~SocketInit() {
    for (CoreLink* link : coreLinks) {
        link->Disconnect();
    }
    WSACleanup();
    std::cout << "Cleaned up Windows socket" << std::endl;
}

CoreLink::CoreLink::CoreLink() :username(), password(), token(), serverIP(), sourcePort(0) {
    SocketInit::instance.coreLinks.push_back(this);

    tcpsock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    udpthreadsock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (tcpsock == INVALID_SOCKET || udpthreadsock == INVALID_SOCKET) {
        std::cout << "Cannot init sockets" << std::endl;
        exit(0);
    }
    
}

CoreLink::CoreLink::CoreLink(const std::string & un, const std::string & pw, const std::string & ip, const u_short & port) : username(un), password(pw), serverIP(), sourcePort(0) {
    SocketInit::instance.coreLinks.push_back(this);

    tcpsock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    udpthreadsock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (tcpsock == INVALID_SOCKET || udpthreadsock == INVALID_SOCKET) {
        std::cout << "Cannot init sockets" << std::endl;
        exit(0);
    }
    Connect(ip, port);
}

CoreLink::CoreLink::~CoreLink() {
    Disconnect();
    closesocket(tcpsock);
    closesocket(tcpthreadsock);
    closesocket(udpthreadsock);
    for (size_t i = 0; i < SocketInit::instance.coreLinks.size();++i) {
        if (SocketInit::instance.coreLinks[i] == this) {
            SocketInit::instance.coreLinks[i] = SocketInit::instance.coreLinks[SocketInit::instance.coreLinks.size() - 1];
            SocketInit::instance.coreLinks.pop_back();
            break;
        }
    }
}

void CoreLink::CoreLink::SetUserData(const std::string & username, const std::string & password) {
    this->username = username;
    this->password = password;
}

void CoreLink::CoreLink::Connect(const std::string & ip, const u_short & port) {
    Disconnect();
    //allow threads to start running
    running = true;
    //connect main tcp socket to server
    hint.sin_family = AF_INET;
    hint.sin_port = htons(port);
    inet_pton(AF_INET, ip.c_str(), &hint.sin_addr);
    if (connect(tcpsock, (sockaddr*)&hint, sizeof(hint)) == SOCKET_ERROR) {
        std::cout << "Cannot connect Windows socket." << std::endl << WSAGetLastError() << std::endl;
        exit(0);
    }
    
    //tell server that client is authenticating and send a token
    rapidjson::Document json;
    json.SetObject();
    json.AddMember("function", rapidjson::Value("auth", 4), json.GetAllocator());
    json.AddMember("username", rapidjson::Value(username.c_str(), username.size()), json.GetAllocator());
    json.AddMember("password", rapidjson::Value(password.c_str(), password.size()), json.GetAllocator());

    rapidjson::StringBuffer jsonbuffer;
    rapidjson::Writer<rapidjson::StringBuffer> jsonwriter(jsonbuffer);
    json.Accept(jsonwriter);

    std::string msg = jsonbuffer.GetString();
    jsonbuffer.Clear();

    std::cout << "Sending: " << msg << std::endl;
    tcp_send(msg);

    char buffer[1024];
    ZeroMemory(buffer, sizeof(buffer));
    int bytesRecieved = recv(tcpsock, buffer, sizeof(buffer), 0);
    std::cout << "Recieved: " << std::string(buffer, 0, bytesRecieved) << std::endl;
    //Get token
    json.Parse(buffer);
    token = json["token"].GetString();

    //Get source ip address. Not too sure what its for
    clientIP = json["ip"].GetString();
    serverIP = ip;
    //init threads
    tcpthreadsock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    tcpSendThread = std::thread(&CoreLink::tcp_send_thread, this);
    udpSendThread = std::thread(&CoreLink::udp_send_thread, this);
    tcpRecvThread = std::thread(&CoreLink::tcp_recv_thread, this);
    udpRecvThread = std::thread(&CoreLink::udp_recv_thread, this);
    recvThread = std::thread(&CoreLink::recv_thread, this);
}

void CoreLink::CoreLink::Disconnect() {
    if (token == "") { return; }
    //stop sending threads
    running = false;
    sourcePort = 0;
    serverIP = "";
    //clear out queues
    tcpSendQueue.clear();
    udpSendQueue.clear();
    recvQueue.clear();
    //push impossible values to unblock locks
    tcpSendQueue.enqueue("");
    udpSendQueue.enqueue("");
    recvQueue.enqueue(std::pair<CoreLink::RecievedPacket, void(*)(const CoreLink::RecievedPacket&)>(CoreLink::RecievedPacket(), nullptr));
    //Join threads
    if (tcpSendThread.joinable()) { tcpSendThread.join(); }
    if (udpSendThread.joinable()) { udpSendThread.join(); }
    if (tcpRecvThread.joinable()) { tcpRecvThread.join(); }
    if (udpRecvThread.joinable()) { udpRecvThread.join(); }
    if (recvThread.joinable()) { recvThread.join(); }
    closesocket(tcpthreadsock);
    //clean up just in case
    tcpSendQueue.clear();
    udpSendQueue.clear();
    recvQueue.clear();

    //clear out streams from corelink server
    rapidjson::Document json;
    json.SetObject();
    json.AddMember("function", rapidjson::Value("disconnect", 10), json.GetAllocator());
    json.AddMember("token", rapidjson::Value(token.c_str(), token.size()), json.GetAllocator());
    json.AddMember("streamid", rapidjson::Value("", 0), json.GetAllocator());

    for (size_t i = 0; i < sendStreams.size(); ++i) {
        json["streamid"].SetString(sendStreams[i].streamID.c_str(), sendStreams[i].streamID.size());
        rapidjson::StringBuffer jsonbuffer;
        rapidjson::Writer<rapidjson::StringBuffer> jsonwriter(jsonbuffer);
        json.Accept(jsonwriter);

        std::string msg = jsonbuffer.GetString();
        jsonbuffer.Clear();

        tcp_send(msg);

        char buffer[1024];
        ZeroMemory(buffer, sizeof(buffer));
        int bytesRecieved = recv(tcpsock, buffer, sizeof(buffer), 0);
        std::cout << "Recieved: " << std::string(buffer, 0, bytesRecieved) << std::endl;
    }

    for (const std::pair<std::string, CoreLink::RecvStreamData>& data : recvStreams) {
        json["streamid"].SetString(data.first.c_str(), data.first.size());
        rapidjson::StringBuffer jsonbuffer;
        rapidjson::Writer<rapidjson::StringBuffer> jsonwriter(jsonbuffer);
        json.Accept(jsonwriter);

        std::string msg = jsonbuffer.GetString();
        jsonbuffer.Clear();

        tcp_send(msg);

        char buffer[1024];
        ZeroMemory(buffer, sizeof(buffer));
        int bytesRecieved = recv(tcpsock, buffer, sizeof(buffer), 0);
        std::cout << "Recieved: " << std::string(buffer, 0, bytesRecieved) << std::endl;

    }
    //clear out streams from client side
    sendStreams.clear();
    recvStreams.clear();

    //clear current token
    token = "";
}

int CoreLink::CoreLink::CreateSenderStream(const std::string & workspace, const int protocol, const std::string & type, const std::string& meta, bool echo) {
    if (protocol != PROTOCOL_TCP && protocol != PROTOCOL_UDP) { return -1; }
    //tell server to create a new sender stream
    rapidjson::Document json;
    json.SetObject();
    json.AddMember("function", rapidjson::Value("sender", 6), json.GetAllocator());
    json.AddMember("workspace", rapidjson::Value(workspace.c_str(), workspace.size()), json.GetAllocator());
    json.AddMember("ip", rapidjson::Value(clientIP.c_str(), clientIP.size()), json.GetAllocator());
    std::string sPort = std::to_string(sourcePort);
    json.AddMember("port", rapidjson::Value(sPort.c_str(), sPort.size()), json.GetAllocator());
    json.AddMember("type", rapidjson::Value(type.c_str(), type.size()), json.GetAllocator());
    json.AddMember("token", rapidjson::Value(token.c_str(), token.size()), json.GetAllocator());
    //not sure if meta data works but will leave it here to be fixed in the future
    json.AddMember("meta", rapidjson::Value(meta.c_str(), meta.size()), json.GetAllocator());
    
    json.AddMember("echo", rapidjson::Value(echo), json.GetAllocator());

    //set the protocol used
    if (protocol == PROTOCOL_TCP) { json.AddMember("proto", rapidjson::Value("tcp", 3), json.GetAllocator()); }
    if (protocol == PROTOCOL_UDP) { json.AddMember("proto", rapidjson::Value("udp", 3), json.GetAllocator()); }

    rapidjson::StringBuffer jsonbuffer;
    rapidjson::Writer<rapidjson::StringBuffer> jsonwriter(jsonbuffer);
    json.Accept(jsonwriter);

    std::string msg = jsonbuffer.GetString();
    jsonbuffer.Clear();

    //Send data and get information about stream
    std::cout << msg << std::endl;
    tcp_send(msg);

    char buffer[1024];
    ZeroMemory(buffer, sizeof(buffer));
    int bytesRecieved = recv(tcpsock, buffer, sizeof(buffer), 0);
    std::cout << "Recieved: " << std::string(buffer, 0, bytesRecieved) << std::endl;

    json.Parse(buffer);

    //Make sure tcp thread socket is initialized only once while it hasn't been closed
    if (sourcePort == 0) { 
        sockaddr_in tcphint;
        tcphint.sin_family = AF_INET;
        inet_pton(AF_INET, serverIP.c_str(), &tcphint.sin_addr);
        tcphint.sin_port = htons(json["port"].GetInt());

        if (connect(tcpthreadsock, (sockaddr*)&tcphint, sizeof(tcphint)) == SOCKET_ERROR) {
            std::cout << "Cannot connect Windows socket." << std::endl << WSAGetLastError() << std::endl;
            exit(0);
        }

        sourcePort = json["port"].GetInt();
    }
    //store sender stream data
    int index = sendStreams.size();
    sendStreams.push_back(CoreLink::CoreLink::SendStreamData());
    sendStreams[index].mtu = json["MTU"].GetInt();
    sendStreams[index].streamID = json["streamid"].GetString();
    sendStreams[index].proto = protocol;
    return index;
}

void CoreLink::CoreLink::StreamSend(const int index, const std::string & msg) {
    if (index < 0 || index >= sendStreams.size()) { return; }
    StreamSend(sendStreams[index].streamID, sendStreams[index].proto, msg);
}

/*
Strange error trying to connect to local node. However it works with server with takes priority currently.
It would be good to someday look back and check if it can be fixed
Also, not sure what to do regarding the alert
*/
void CoreLink::CoreLink::CreateRecieverStream(const std::string & workspace, const int protocol, const std::vector<std::string>& type, bool echo, bool alert, void(*func)(const CoreLink::RecievedPacket &)) {
    //tell server to create a new reciever stream
    if (protocol != PROTOCOL_TCP && protocol != PROTOCOL_UDP) { return; }
    //tell server to create a new sender stream
    rapidjson::Document json;
    json.SetObject();
    json.AddMember("function", rapidjson::Value("receiver", 8), json.GetAllocator());
    json.AddMember("workspace", rapidjson::Value(workspace.c_str(), workspace.size()), json.GetAllocator());
    json.AddMember("ip", rapidjson::Value(clientIP.c_str(), clientIP.size()), json.GetAllocator());
    std::string sPort = std::to_string(sourcePort);
    json.AddMember("port", rapidjson::Value(sPort.c_str(), sPort.size()), json.GetAllocator());
    rapidjson::Value typeArr(rapidjson::kArrayType);
    for (const std::string& t : type) {
        typeArr.PushBack(rapidjson::Value(t.c_str(), t.size()), json.GetAllocator());
    }
    json.AddMember("type", typeArr, json.GetAllocator());
    json.AddMember("token", rapidjson::Value(token.c_str(), token.size()), json.GetAllocator());

    json.AddMember("echo", rapidjson::Value(echo), json.GetAllocator());
    json.AddMember("alert", rapidjson::Value(alert), json.GetAllocator());

    //set the protocol used
    if (protocol == PROTOCOL_TCP) { json.AddMember("proto", rapidjson::Value("tcp", 3), json.GetAllocator()); }
    if (protocol == PROTOCOL_UDP) { json.AddMember("proto", rapidjson::Value("udp", 3), json.GetAllocator()); }

    rapidjson::StringBuffer jsonbuffer;
    rapidjson::Writer<rapidjson::StringBuffer> jsonwriter(jsonbuffer);
    json.Accept(jsonwriter);

    std::string msg = jsonbuffer.GetString();
    jsonbuffer.Clear();

    std::cout << msg << std::endl;
    tcp_send(msg);

    char buffer[1024];
    ZeroMemory(buffer, sizeof(buffer));
    int bytesRecieved = recv(tcpsock, buffer, sizeof(buffer), 0);
    std::cout << "Recieved: " << std::string(buffer, 0, bytesRecieved) << std::endl;

    json.Parse(buffer);
    //Might want to throw exceptions but for now, focus on getting it working
    //if (json["statuscode"].GetInt != 0) { throw std::exception("Cannot initialize reciever"); }
    if (json["statuscode"].GetInt() != 0) {
        std::cout << "Cannot initialize reciever" << std::endl;
        return;
    }

    //Make sure tcp thread socket is initialized only once while it hasn't been closed
    if (sourcePort == 0) {
        sockaddr_in tcphint;
        tcphint.sin_family = AF_INET;
        inet_pton(AF_INET, serverIP.c_str(), &tcphint.sin_addr);
        tcphint.sin_port = htons(json["port"].GetInt());

        if (connect(tcpthreadsock, (sockaddr*)&tcphint, sizeof(tcphint)) == SOCKET_ERROR) {
            std::cout << "Cannot connect Windows socket." << std::endl << WSAGetLastError() << std::endl;
            exit(0);
        }
        sourcePort = json["port"].GetInt();
    }
    std::string streamID = json["streamid"].GetString();
    recvStreams[streamID] = CoreLink::RecvStreamData();
    recvStreams[streamID].func = func;
    recvStreams[streamID].proto = protocol;
    recvStreams[streamID].mtu = json["MTU"].GetInt();

    rapidjson::Value& arr = json["streamlist"];
    for (rapidjson::SizeType i = 0; i < arr.Size(); ++i) {
        std::string inStreamID = arr[i]["streamid"].GetString();
        if (recvStreamPtrs.find(inStreamID) == recvStreamPtrs.end()) {
            recvStreamPtrs[inStreamID] = { streamID };
        }
        else {
            recvStreamPtrs[inStreamID].push_back(streamID);
        }
    }
    //send back message to corelink
    StreamSend(streamID, recvStreams[streamID].proto, "0");
}

bool CoreLink::CoreLink::tcp_send(const std::string & msg, int len) {
    //Helper function to send tcp messages to server
    int sendVal;
    const char* buffer = msg.c_str();
    len = (len <= -1) ? msg.size() : len;
    while (len > 0) {
        sendVal = send(tcpsock, buffer + msg.size() - len, len, 0);
        if (sendVal == SOCKET_ERROR) {
            std::cout << "Error sending message." << std::endl << WSAGetLastError() << std::endl;
            return false;
        }
        len -= sendVal;
    }
    return true;
}

void CoreLink::CoreLink::tcp_send_thread() {
    while (sourcePort == 0 && running) { continue; }
    if (!running) { return; }
    while (running) {
        std::string msg = tcpSendQueue.dequeue();
        if (msg == "") { continue; }
        //std::cout << msg << ' ' << serverIP << ' ' << sourcePort << std::endl;
        int sendVal;
        int len = msg.size();
        const char* buffer = msg.c_str();
        while (len > 0) {
            sendVal = send(tcpthreadsock, buffer + msg.size() - len, len, 0);
            if (sendVal == SOCKET_ERROR) {
                std::cout << "Error sending message." << std::endl << WSAGetLastError() << std::endl;
                continue;
            }
            len -= sendVal;
        }
    }
}

void CoreLink::CoreLink::udp_send_thread() {
    sockaddr_in udphint;
    udphint.sin_family = AF_INET;
    while (sourcePort == 0 && running) { continue; }
    inet_pton(AF_INET, serverIP.c_str(), &udphint.sin_addr);
    if (!running) { return; }
    udphint.sin_port = htons(sourcePort);
    while (running) {
        std::string msg = udpSendQueue.dequeue();
        if (msg == "") { continue; }

        int sendOk = sendto(udpthreadsock, msg.c_str(), msg.size(), 0, (sockaddr*)&udphint, sizeof(udphint));
        if (sendOk == SOCKET_ERROR) {
            std::cout << "Error sending to server " << WSAGetLastError() << std::endl;
        }
    }
}

void CoreLink::CoreLink::StreamSend(const std::string & streamid, const int proto, const std::string & msg) {
    std::chrono::milliseconds ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
    std::string timestr = std::to_string(ms.count());
    rapidjson::Document json;
    json.SetObject();
    json.AddMember("id", rapidjson::Value(streamid.c_str(), streamid.size()), json.GetAllocator());
    json.AddMember("time", rapidjson::Value(timestr.c_str(), timestr.size()), json.GetAllocator());

    rapidjson::StringBuffer jsonbuffer;
    rapidjson::Writer<rapidjson::StringBuffer> jsonwriter(jsonbuffer);
    json.Accept(jsonwriter);

    std::string header = jsonbuffer.GetString();
    jsonbuffer.Clear();

    unsigned int hsize = header.size();
    unsigned int msize = msg.size();
    std::stringstream sendStr;
    //note that its in little endian
    sendStr << (char)(hsize & 0xFF) << (char)((hsize >> 8) & 0xFF);
    sendStr << (char)(msize & 0xFF) << (char)((msize >> 8) & 0xFF) << (char)((msize >> 16) & 0xFF) << (char)((msize >> 24) & 0xFF);
    sendStr << header << msg;
    //std::cout << sendStr.str() << std::endl;
    if (proto == PROTOCOL_TCP) { tcpSendQueue.enqueue(sendStr.str()); }
    if (proto == PROTOCOL_UDP) { udpSendQueue.enqueue(sendStr.str()); }

    sendStr.clear();
}


void CoreLink::CoreLink::tcp_recv_thread() {
    while (sourcePort == 0 && running) { continue; }
    if (!running) { return; }
    while (running) {
        char recvbuffer[1024];
        ZeroMemory(recvbuffer, sizeof(recvbuffer));
        int bytesRecieved = recv(tcpthreadsock, recvbuffer, sizeof(recvbuffer), 0);
        proc_message(recvbuffer, bytesRecieved);
    }
}

void CoreLink::CoreLink::udp_recv_thread() {
    sockaddr_in udphint;
    udphint.sin_family = AF_INET;
    int hintlen = sizeof(udphint);
    while (sourcePort == 0 && running) { continue; }
    inet_pton(AF_INET, serverIP.c_str(), &udphint.sin_addr);
    if (!running) { return; }
    udphint.sin_port = htons(sourcePort);
    while (running) {
        char recvbuffer[1024];
        ZeroMemory(recvbuffer, sizeof(recvbuffer));
        int bytesRecieved = recvfrom(udpthreadsock, recvbuffer, sizeof(recvbuffer), 0, (sockaddr*)&udphint, &hintlen);
        char ipaddr[256];
        inet_ntop(AF_INET, &udphint.sin_addr, ipaddr, sizeof(ipaddr));
        //make sure its from server and has something
        if (bytesRecieved > 0 && serverIP == ipaddr) {
            proc_message(recvbuffer, bytesRecieved);
        }
    }
}

void CoreLink::CoreLink::proc_message(char * ptr, int len) {
    unsigned int hsize = ptr[0] + (ptr[1] << 8);
    unsigned int msize = ptr[2] + (ptr[3] + (ptr[4] + (ptr[5] << 8) << 8) << 8);
    //ignore invalid messages
    if (hsize + msize + 6 != len) {
        return;
    }
    rapidjson::Document json;
    json.SetObject();
    json.Parse((const char*)(ptr + 6), hsize);
    CoreLink::RecievedPacket packet;
    packet.streamID = json["id"].GetString();
    packet.time = atoll(json["time"].GetString());
    packet.msg = std::string((const char*)(ptr + 6 + hsize), msize);

    for (const std::string& recv : recvStreamPtrs[packet.streamID]) {
        recvQueue.enqueue(std::pair<CoreLink::RecievedPacket, void(*)(const CoreLink::RecievedPacket&)>(packet, recvStreams[recv].func));
    }
}

void CoreLink::CoreLink::recv_thread() {
    while (running) {
        std::pair<CoreLink::RecievedPacket, void(*)(const CoreLink::RecievedPacket&)> data = recvQueue.dequeue();
        if (data.second == nullptr) { continue; }
        data.second(data.first);
    }
}
